# ugfx-arduino-gdisp-ssd1351
SSD1351 driver for ugfx-arduino
