#ifndef TEENSY31_SSD1351_UGFX_CONFIG_H
#define TEENSY31_SSD1351_UGFX_CONFIG_H

#include <ugfx-arduino.h> // main library
#include <ugfx-arduino-gdisp-ssd1351.h> // display driver library

#endif // TEENSY31_SSD1351_UGFX_CONFIG_H
