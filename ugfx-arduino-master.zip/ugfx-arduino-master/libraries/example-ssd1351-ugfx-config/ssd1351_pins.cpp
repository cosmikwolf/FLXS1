#include "ugfx-arduino-gdisp-ssd1351.h"

extern const ssd1351_pins_t ssd1351_pins = {15, 14, 16};
