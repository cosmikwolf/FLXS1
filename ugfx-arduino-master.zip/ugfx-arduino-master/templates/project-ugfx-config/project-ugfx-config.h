#ifndef PROJECT_UGFX_CONFIG_H
#define PROJECT_UGFX_CONFIG_H

#include <ugfx-arduino.h> // main library
#include <ugfx-arduino-DISPLAY.h> // add a suitable display driver library header
// example: #include <ugfx-arduino-gdisp-ssd1351.h>

#endif // PROJECT_UGFX_CONFIG_H
