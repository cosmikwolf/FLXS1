#ifndef UGFX_ARDUINO_H
#define UGFX_ARDUINO_H

#include <gfx.h>  // and use gfx.h in that directory

#endif // UGFX_ARDUINO_H
