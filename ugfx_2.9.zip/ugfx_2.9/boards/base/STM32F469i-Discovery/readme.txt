Note this board definition is definitly incomplete.

Please someone help us complete it!
