Copy these files into your own project directory and alter them to suite.

Notes:

1/ To run please install eCos synthetic framebuffer according to the documentation.
2/ Call application ./ugfx_over_ecos -io