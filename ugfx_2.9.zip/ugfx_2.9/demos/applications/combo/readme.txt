This demo supports input from both a mouse/touch, toggles and/or a dial input.
If your platform does not support one or the other, turn it off in
gfxconf.h

Note that you will need to include the drivers into your project
makefile for whichever inputs you decide to use.

For some fun have a play with the "colors" radio group and the "Disable All" checkbox.
