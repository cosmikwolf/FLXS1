#ifndef _TASKS_INCLUDED
#define _TASKS_INCLUDED

void doMandlebrot(GHandle parent, gBool start);
void doBounce(GHandle parent, gBool start);

#endif
