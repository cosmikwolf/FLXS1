!#/bin/bash

./file2c -c -n jg10_1 -f 1.bmp 1.bmp ../romfs_1.h
./file2c -c -n jg10_2 -f 2.bmp 2.bmp ../romfs_2.h
./file2c -c -n jg10_3 -f 3.bmp 3.bmp ../romfs_3.h
./file2c -c -n jg10_4 -f 4.bmp 4.bmp ../romfs_4.h
./file2c -c -n jg10_5 -f 5.bmp 5.bmp ../romfs_5.h
./file2c -c -n jg10_6 -f 6.bmp 6.bmp ../romfs_6.h
./file2c -c -n jg10_7 -f 7.bmp 7.bmp ../romfs_7.h
./file2c -c -n jg10_8 -f 8.bmp 8.bmp ../romfs_8.h
./file2c -c -n jg10_9 -f 9.bmp 9.bmp ../romfs_9.h
./file2c -c -n jg10_10 -f 10.bmp 10.bmp ../romfs_10.h
./file2c -c -n jg10_11 -f 11.bmp 11.bmp ../romfs_11.h
./file2c -c -n jg10_12 -f 12.bmp 12.bmp ../romfs_12.h
./file2c -c -n jg10_13 -f 13.bmp 13.bmp ../romfs_13.h
./file2c -c -n jg10_14 -f 14.bmp 14.bmp ../romfs_14.h
./file2c -c -n jg10_15 -f 15.bmp 15.bmp ../romfs_15.h
./file2c -c -n jg10_16 -f 15.bmp 16.bmp ../romfs_16.h
./file2c -c -n jg10_17 -f 15.bmp 17.bmp ../romfs_17.h
./file2c -c -n jg10_18 -f 15.bmp 18.bmp ../romfs_18.h
./file2c -c -n jg10_19 -f 15.bmp 19.bmp ../romfs_19.h
./file2c -c -n jg10_20 -f 15.bmp 20.bmp ../romfs_20.h
./file2c -c -n jg10_a1 -f a1.bmp a1.bmp ../romfs_a1.h
./file2c -c -n jg10_a2 -f a2.bmp a2.bmp ../romfs_a2.h
./file2c -c -n jg10_a3 -f a3.bmp a3.bmp ../romfs_a3.h
./file2c -c -n jg10_a4 -f a4.bmp a4.bmp ../romfs_a4.h
./file2c -c -n jg10_a5 -f a5.bmp a5.bmp ../romfs_a5.h
./file2c -c -n jg10_background -f background.bmp background.bmp ../romfs_background.h
./file2c -c -n jg10_splash -f splash.bmp splash.bmp ../romfs_splash.h
./file2c -c -n jg10_splashclr -f splashclr.bmp splashclr.bmp ../romfs_splashclr.h
./file2c -c -n jg10_splashtxt -f splashtxt.bmp splashtxt.bmp ../romfs_splashtxt.h


