A demo Minesweeper game using. Various configuration options can be found in mines.h

NOTE: You can save FLASH space by disabling the splash-screen, to do that set MINES_SHOW_SPLASH to GFXOFF.

Credits:
	Code:	Fleck
	Images:	I-Wish
