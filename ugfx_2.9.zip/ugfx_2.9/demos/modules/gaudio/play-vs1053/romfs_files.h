/**
 * This file contains the list of files for the ROMFS.
 *
 * The files have been converted using...
 * 		file2c -dbcs infile outfile
 */
#include "romfs_allwrong.h"
